module com.example {
    requires transitive javafx.graphics;
    requires transitive java.desktop;
    requires javafx.controls;
    exports com.example;
}
